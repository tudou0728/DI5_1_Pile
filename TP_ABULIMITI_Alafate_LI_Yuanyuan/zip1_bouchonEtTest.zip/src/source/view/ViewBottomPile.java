package source.view;

import java.util.Observable;
import java.util.Observer;

import source.pile.Pile;


public class ViewBottomPile implements Observer {
	public  int count=0;
	
	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		Pile pile =(Pile) o;
		count++;
		System.out.println("pilote viewBottom");
	}
}

package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import source.pile.Pile;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

/**
 * la classe pour tester pileScenario3
 * @author Yuanyuan
 *
 */
public class TestScenario3 {
	@Test
	public void pileScenario3() {
		Pile pile=new Pile();
		ViewBottomPile viewBottomPile=new ViewBottomPile();
		ViewTopPile viewTopPile=new ViewTopPile();
		pile.addObserver(viewTopPile);
		pile.addObserver(viewBottomPile);
		pile.push(1);
		assertEquals(1,viewBottomPile.count);
		assertEquals(1,viewTopPile.count);
		pile.push(1);
		pile.push(2);
		pile.push(3);
		pile.push(4);
		assertEquals(5,viewBottomPile.count);
		assertEquals(5,viewTopPile.count);
		pile.push(5);
		assertEquals(6,viewBottomPile.count);
		assertEquals(6,viewTopPile.count);
		int pop=pile.pop();
		assertEquals(7,viewBottomPile.count);
		assertEquals(7,viewTopPile.count);
		pile.clear();
		assertEquals(8, viewBottomPile.count);
		assertEquals(8, viewTopPile.count);
	}

}

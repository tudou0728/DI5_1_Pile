package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import source.pile.Pile;
import source.view.ViewBottomPile;

public class TestViewBottom {
	private Pile pile=new Pile();
	private ViewBottomPile viewBottomPile=new ViewBottomPile();
	
	@Test
	public void testView() {
		pile.addObserver(viewBottomPile);
		pile.push(11);
		pile.push(13);
		pile.push(12);
		assertEquals(3,viewBottomPile.count);
		pile.push(15);
		pile.push(16);
		pile.push(11);
		pile.push(18);
		assertEquals(7,viewBottomPile.count);
	}

}

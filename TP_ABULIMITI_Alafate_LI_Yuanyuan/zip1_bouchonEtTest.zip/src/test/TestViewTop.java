package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import source.pile.Pile;
import source.view.ViewTopPile;

public class TestViewTop {
	private Pile pile=new Pile();
	private ViewTopPile viewTop=new ViewTopPile();
	
	@Test
	public void testView() {
		pile.addObserver(viewTop);
		pile.push(5);
		pile.push(1);
		assertEquals(2,viewTop.count);
		pile.push(3);
		pile.push(6);
		assertEquals(4,viewTop.count);
		pile.push(10);
		assertEquals(5,viewTop.count);
	}
}

package input;

import source.pile.Pile;

public abstract class InputPileStrategy {
	
	public Pile pile;
	public String action;
	
	public InputPileStrategy() {
		pile = new Pile();
	}
	
	public void push(int entier) {

		pile.push(entier);
	}

	public Integer pop() {

		return pile.pop();
	}

	public void clear() {
		
		pile.clear();
	}

	public abstract void actionCommande();

}

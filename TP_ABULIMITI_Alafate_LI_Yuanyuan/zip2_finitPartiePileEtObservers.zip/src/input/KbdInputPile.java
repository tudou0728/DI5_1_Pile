package input;

/**
 * pilote
 * @author Alafate
 *
 */
public class KbdInputPile extends InputPileStrategy {

	public String action;
	public int num;
	
	@Override
	public void actionCommande() {
		if(action.equals("pop"))
			this.pop();
		else if(action.equals("push"))
			this.push(num);
		else if(action.equals("clear"))
			this.clear();
	
	}

}

package input;

/**
 * pilote
 * @author Alafate
 *
 */
public class ViewInputPile extends InputPileStrategy {
	public String action;
	public int num = 0;
	
	@Override
	public void actionCommande() {
		if(action.equals("pop"))
			this.pop();
		else if(action.equals("push"))
			this.push(num);
		else if(action.equals("clear"))
			this.clear();
	}
}

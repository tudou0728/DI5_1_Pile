package source.pile;

import source.view.ViewBottomPile;
import source.view.ViewTopPile;

/**
 * classe pour debug
 * @author Yuanyuan
 *
 */
public class DebugScenarioTotal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pile pile=new Pile();
		ViewBottomPile viewBottomPile=new ViewBottomPile();
		ViewTopPile viewTopPile=new ViewTopPile();
		pile.addObserver(viewTopPile);
		pile.addObserver(viewBottomPile);
		pile.push(1);
		pile.push(1);
		pile.push(2);
		pile.push(3);
		pile.push(4);
		pile.push(6);
		pile.clear();
	}

}

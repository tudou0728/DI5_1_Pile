package source.pile;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

public class Pile extends Observable {
	private static List<Integer> pile = new ArrayList<Integer>();

	public Integer getSizeList() {
		return pile.size();
	}

	public Integer getEntier(int index) {
		return pile.get(index);
	}

	public  void push(int entier) {
		pile.add(entier);
		setChanged();
		this.notifyObservers(this);
	}
	
	public Integer pop() {
		if(this.getSizeList()>0) {
			Integer pop=pile.get(0);
			pile.remove(this.getSizeList()-1);
			setChanged();
			this.notifyObservers(this);
			return pop;
		}
		else {
			return -1;
		}
	}

	public  void clear() {
		pile.clear();
		setChanged();
		this.notifyObservers(this);
	}
}

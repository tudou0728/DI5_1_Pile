package source.view;

import java.util.Observable;
import java.util.Observer;

import source.pile.Pile;

/**
 * classe vraie
 * @author Yuanyuan
 *
 */
public class ViewTopPile implements Observer{

	private int top;
	
	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		Pile pile =(Pile) o;
		try {
			this.top=pile.getEntier(pile.getSizeList()-1);
			System.out.println("Top de la pile est: "+top);
		}catch (Exception e) {
			// TODO: handle exception
			top=-1;
			System.out.println("Top: la pile est vide");
		}
	}

	public int getTop() {
		return this.top;
	}
}

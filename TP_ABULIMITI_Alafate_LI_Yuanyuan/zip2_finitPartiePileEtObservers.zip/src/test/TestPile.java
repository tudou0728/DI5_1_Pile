package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import source.pile.Pile;

/**
 * Test unitaire pour la classe Pile
 * @author Yuanyuan
 *
 */
public class TestPile {
	
	private Pile pile = new Pile();
	
	@Test
	public void testPush() {
		pile.clear();
		pile.push(5);
		assertEquals(5,pile.getEntier(0).intValue());
	}
	
	@Test
	public void testPop() {
		pile.clear();
		pile.push(5);
		int pop=pile.pop().intValue();
		assertEquals(5,pop);
	}
	
	@Test
	public void testSize() {
		pile.clear();
		pile.push(1);
		pile.push(2);
		pile.push(3);
		pile.push(4);
		pile.push(5);
		assertEquals(5,pile.getSizeList().intValue());
	}
}

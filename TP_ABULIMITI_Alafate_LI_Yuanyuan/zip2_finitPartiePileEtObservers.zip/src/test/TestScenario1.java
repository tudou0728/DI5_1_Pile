package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import input.KbdInputPile;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

/**
 * la calsse pour tester pileScenario1
 * @author Yuanyuan
 *
 */
public class TestScenario1 {
	
	@Test
	public void pileScenario1() {
		KbdInputPile kbdInputPile=new KbdInputPile();
		ViewBottomPile viewBottomPile=new ViewBottomPile();
		ViewTopPile viewTopPile=new ViewTopPile();
		kbdInputPile.pile.addObserver(viewBottomPile);
		kbdInputPile.pile.addObserver(viewTopPile);
		kbdInputPile.action="push";
		kbdInputPile.num=10;
		for(int i=0;i<5;i++) {
		kbdInputPile.actionCommande();	
		}
		assertEquals(10,viewTopPile.getTop());
		assertEquals(10,viewBottomPile.getBottom().get(0).intValue());
		kbdInputPile.num=11;
		kbdInputPile.actionCommande();	
		assertEquals(11,viewTopPile.getTop());
		assertEquals(10,viewBottomPile.getBottom().get(0).intValue());
	}

}

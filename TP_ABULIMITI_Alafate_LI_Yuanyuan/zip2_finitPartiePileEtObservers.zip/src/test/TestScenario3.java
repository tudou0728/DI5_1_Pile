package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import source.pile.Pile;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

/**
 * la classe pour tester pileScenario3
 * @author Yuanyuan
 *
 */
public class TestScenario3 {
	@Test
	public void pileScenario3() {
		Pile pile=new Pile();
		ViewBottomPile viewBottomPile=new ViewBottomPile();
		ViewTopPile viewTopPile=new ViewTopPile();
		pile.addObserver(viewTopPile);
		pile.addObserver(viewBottomPile);
		pile.push(1);
		assertEquals(1,viewBottomPile.getBottom().get(0).intValue());
		assertEquals(1,viewTopPile.getTop());
		pile.push(1);
		pile.push(2);
		pile.push(3);
		pile.push(4);
		assertEquals(1,viewBottomPile.getBottom().get(0).intValue());
		assertEquals(4,viewTopPile.getTop());
		pile.push(5);
		assertEquals(1,viewBottomPile.getBottom().get(0).intValue());
		assertEquals(5,viewTopPile.getTop());
		int pop=pile.pop();
		assertEquals(1,viewBottomPile.getBottom().get(0).intValue());
		assertEquals(4,viewTopPile.getTop());
		pile.clear();
		assertEquals(0, viewBottomPile.getBottom().size());
		assertEquals(-1, viewTopPile.getTop());
	}

}

package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import source.pile.Pile;
import source.view.ViewBottomPile;

public class TestViewBottom {
	private Pile pile=new Pile();
	private ViewBottomPile viewBottomPile=new ViewBottomPile();
	
	@Test
	public void testView() {
		pile.addObserver(viewBottomPile);
		pile.push(11);
		pile.push(13);
		pile.push(12);
		assertEquals(11,viewBottomPile.getBottom().get(0).intValue());
		assertEquals(13,viewBottomPile.getBottom().get(1).intValue());
		pile.push(15);
		pile.push(16);
		pile.push(11);
		pile.push(18);
		assertEquals(11,viewBottomPile.getBottom().get(0).intValue());
		assertEquals(16,viewBottomPile.getBottom().get(4).intValue());
	}

}

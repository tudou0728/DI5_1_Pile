package test;

import input.KbdInputPile;
import junit.framework.TestCase;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

public class TestkbdInputClear extends TestCase {
	private KbdInputPile kbdi;
	private ViewTopPile viewtop;
	private ViewBottomPile viewBottom;

	
	protected void setUp() throws Exception {
		super.setUp();
		kbdi = new KbdInputPile();
		kbdi.action = "push";
		kbdi.num = 100;
		
		for(int i=0; i<6; i++) {
			kbdi.actionCommande();
		}
		
		viewtop = new ViewTopPile();
		viewBottom = new ViewBottomPile();
		kbdi.pile.addObserver(viewtop);
		kbdi.pile.addObserver(viewBottom);
		
		
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	
	public void testMethod() {
	}
	

}

package test;

import input.KbdInputPile;
import junit.framework.TestCase;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;


public class TestkbdInputPop extends TestCase {
	private KbdInputPile kbdi;
	private ViewTopPile viewtop;
	private ViewBottomPile viewBottom;

	
	protected void setUp() throws Exception {
		super.setUp();
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testMethod() {

	}
	
}

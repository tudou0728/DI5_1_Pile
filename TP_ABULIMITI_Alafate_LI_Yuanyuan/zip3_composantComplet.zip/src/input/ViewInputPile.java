package input;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import source.view.ViewBottomPile;
import source.view.ViewTopPile;


public class ViewInputPile extends InputPileStrategy {
	private static JFrame frame = new JFrame();
	private static ViewBottomPile viewBottomPile = new ViewBottomPile();
	private static ViewTopPile viewTopPile = new ViewTopPile();
	public String action;
	public int num = 0;
	
	@Override
	public void actionCommande() {
		if(action.equals("pop"))
			this.pop();
		else if(action.equals("push"))
			this.push(num);
		else if(action.equals("clear"))
			this.clear();
	}
	
	public  ViewInputPile() {
		pile.addObserver(viewBottomPile);
		pile.addObserver(viewTopPile);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 450, 300);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		frame.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Base : ");
		lblNewLabel.setBounds(93, 192, 61, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Sommet : ");
		lblNewLabel_1.setBounds(93, 240, 71, 16);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(212, 192, 61, 16);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(212, 240, 61, 16);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("POP");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				action = "pop";
				actionCommande();

				int longeur=viewBottomPile.getBottom().size();
				
				int top = viewTopPile.getTop();
				if (longeur==0 || top == -1) {
					lblNewLabel_2.setText("");
					lblNewLabel_3.setText("");
				} else {
//					int bottom = viewBottomPile.getBottom().get(0);
					String bottom=viewBottomPile.bottomString();
					lblNewLabel_2.setText(bottom);
					lblNewLabel_3.setText(Integer.toString(top));
				}
			}
		});
		btnNewButton.setBounds(0, 131, 117, 29);
		contentPane.add(btnNewButton);

		JTextField textField = new JTextField();
		textField.setBounds(179, 57, 71, 51);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("PUSH");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String input = textField.getText().toString();
				
				int intputInt;
				try {				
					actionCommande();
					intputInt = Integer.parseInt(input);
					action = "push";
					num = intputInt;
					String bottom = viewBottomPile.bottomString();
					int top = viewTopPile.getTop();
					lblNewLabel_2.setText(bottom);
					lblNewLabel_3.setText(Integer.toString(top));
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(frame,"Ce n'est pas un entier", "erreur", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(156, 131, 117, 29);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("CLEAR");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				action = "clear";
				actionCommande();
				String bottom = viewBottomPile.bottomString();
				int top = viewTopPile.getTop();
				lblNewLabel_2.setText("");
				lblNewLabel_3.setText("");
			}
		});
		btnNewButton_2.setBounds(311, 131, 117, 29);
		contentPane.add(btnNewButton_2);
		frame.setVisible(true);
	}
}

package source.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import source.pile.Pile;

public class ViewBottomPile implements Observer {

	private List<Integer> bottom= new ArrayList<Integer>();
	
	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		Pile pile =(Pile) o;
		bottom.clear();
		try {
			System.out.println("Les 5 premiers éléments de la pile sont: ");
			if(pile.getSizeList()<5 && pile.getSizeList()>0) {
				for(int i=0;i<pile.getSizeList();i++) {
					this.bottom.add(pile.getEntier(i));
					System.out.println(pile.getEntier(i));
				}
			}else if(pile.getSizeList()>=5) {
				for(int i=0;i<5;i++) {
					this.bottom.add(pile.getEntier(i));
					System.out.println(pile.getEntier(i));
				}
			}else {
				System.out.println("Bottom: la pile est vide");
			}	
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Bottom: la pile est vide");
		}
	}
	public List<Integer> getBottom() {
		return this.bottom;
	}
	
	public String bottomString() {
		String resultat="";
		if(bottom.size()>0) {
			for(int i=0;i<bottom.size();i++) {
				resultat=resultat+" "+bottom.get(i);
			}
		}
		else {
			resultat="Bottom: la pile est vide";
		}
		return resultat;
	}
}

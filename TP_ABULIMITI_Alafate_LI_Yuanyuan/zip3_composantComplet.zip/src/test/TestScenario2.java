package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import input.ViewInputPile;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

/**
 * la classe pour tester vueScenario2
 * @author Yuanyuan
 *
 */
public class TestScenario2 {
	
	@Test
	public void vueScenario2() {
		ViewInputPile viewInputPile=new ViewInputPile();
		ViewBottomPile viewBottomPile=new ViewBottomPile();
		ViewTopPile viewTopPile=new ViewTopPile();
		viewInputPile.pile.addObserver(viewBottomPile);
		viewInputPile.pile.addObserver(viewTopPile);
		viewInputPile.action="push";
		viewInputPile.num=10;
		for(int i=0;i<5;i++) {
			viewInputPile.actionCommande();	
		}
		assertEquals(10,viewTopPile.getTop());
		assertEquals(10,viewBottomPile.getBottom().get(0).intValue());
		viewInputPile.num=11;
		viewInputPile.actionCommande();	
		assertEquals(11,viewTopPile.getTop());
		assertEquals(10,viewBottomPile.getBottom().get(0).intValue());
	}

}

package test;



import input.KbdInputPile;
import junit.framework.TestCase;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

public class TestkbdInputPush extends TestCase {
	private KbdInputPile kbdi;
	private ViewTopPile viewtop;
	private ViewBottomPile viewBottom;
	
	protected void setUp() throws Exception {
		super.setUp();
		kbdi = new KbdInputPile();
		kbdi.action = "push";
		kbdi.num = 100;
		
		viewtop = new ViewTopPile();
		viewBottom = new ViewBottomPile();
		kbdi.pile.addObserver(viewtop);
		kbdi.pile.addObserver(viewBottom);
		
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	
	public void testMethod() {
		for(int i=0; i<10; i++) {
			kbdi.actionCommande();
			TestCase.assertEquals(Integer.valueOf(i+1), kbdi.pile.getSizeList());
			TestCase.assertEquals(100, viewtop.getTop());
			TestCase.assertEquals(i+1, viewBottom.getBottom().size());
		}
		
		
		kbdi.actionCommande();
		TestCase.assertEquals(Integer.valueOf(6), kbdi.pile.getSizeList());
		TestCase.assertEquals(5, viewBottom.getBottom().size());
		TestCase.assertEquals(100, viewtop.getTop());
	}
	

}

package tpPile;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import source.pile.Pile;
import source.view.ViewBottomPile;
import source.view.ViewTopPile;

/**
 * classe pour debug
 * @author Alafate
 *
 */
public class testframe extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private static Pile pile = new Pile();
	private static ViewBottomPile viewBottomPile = new ViewBottomPile();
	private static ViewTopPile viewTopPile = new ViewTopPile();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pile.addObserver(viewBottomPile);
					pile.addObserver(viewTopPile);
					testframe frame = new testframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public testframe() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Base : ");
		lblNewLabel.setBounds(93, 192, 61, 16);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Sommet : ");
		lblNewLabel_1.setBounds(93, 240, 71, 16);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(212, 192, 61, 16);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(212, 240, 61, 16);
		contentPane.add(lblNewLabel_3);

		JButton btnNewButton = new JButton("POP");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pile.pop();

				int longeur=viewBottomPile.getBottom().size();
				int top = viewTopPile.getTop();
				if (longeur==0 || top == -1) {
					lblNewLabel_2.setText("");
					lblNewLabel_3.setText("");
				} else {
//					int bottom = viewBottomPile.getBottom().get(0);
					String bottom=viewBottomPile.bottomString();
					lblNewLabel_2.setText(bottom);
					lblNewLabel_3.setText(Integer.toString(top));
				}
			}
		});
		btnNewButton.setBounds(0, 131, 117, 29);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("PUSH");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String input = textField.getText().toString();

				int intputInt;
				try {
					intputInt = Integer.parseInt(input);
					pile.push(intputInt);
//					int bottom = viewBottomPile.getBottom().get(0);
					String bottom=viewBottomPile.bottomString();
					int top = viewTopPile.getTop();
					lblNewLabel_2.setText(bottom);
					lblNewLabel_3.setText(Integer.toString(top));
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(rootPane, "Ce n'est pas un entier", "erreur",
							JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(156, 131, 117, 29);
		contentPane.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("CLEAR");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pile.clear();
//				int bottom = viewBottomPile.getBottom().get(0);
//				int top = viewTopPile.getTop();
				lblNewLabel_2.setText("");
				lblNewLabel_3.setText("");
			}
		});
		btnNewButton_2.setBounds(311, 131, 117, 29);
		contentPane.add(btnNewButton_2);

		textField = new JTextField();
		textField.setBounds(179, 57, 71, 51);
		contentPane.add(textField);
		textField.setColumns(10);
	}

}
